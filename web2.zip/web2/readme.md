# Pomorodo Timer - Tasbeeh Ismaeel 
## how to run ? 
1. unzip the folder
2. open terminal: npx webpack serve --mode development --open
## contain? 
4 modules each one does it's functionality and a sound system when the timer is up 
## method ? 
# after 4 sessions the break turns into 15 mins long break, other wise it's 5 mins break for 25 mins working. 
# the system count cycles


