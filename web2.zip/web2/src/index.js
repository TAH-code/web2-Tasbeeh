import { startPomodoro, stopPomodoro, resetPomodoro } from "./js/timer.js";
import { startBtn, stopBtn, resetBtn } from "./js/ui.js";
import "./style.css";

startBtn.addEventListener("click", startPomodoro);
stopBtn.addEventListener("click", stopPomodoro);
resetBtn.addEventListener("click", resetPomodoro);
