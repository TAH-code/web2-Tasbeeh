import { updateTimerDisplay } from "./ui.js";
import { playNotificationSound } from "./notification.js";
import { getUserSettings } from "./settings.js";

let startTimer = null;
let sessionCount = 0;

export function startPomodoro() {
    if (!startTimer) {
        startTimer = setInterval(timer, 1000);
    } else {
        alert("Timer is already running");
    }
}

export function stopPomodoro() {
    clearInterval(startTimer);
    startTimer = null;
}

export function resetPomodoro() {
    stopPomodoro();
    const { workDuration, breakDuration } = getUserSettings();
    updateTimerDisplay(workDuration, 0, breakDuration, 0);
    document.getElementById("counter").innerText = 0;
    sessionCount = 0;
}


function timer() {
    let wm = document.getElementById("w_minutes");
    let ws = document.getElementById("w_seconds");
    let bm = document.getElementById("b_minutes");
    let bs = document.getElementById("b_seconds");


        if (wm.innerText > 0 || ws.innerText > 0) {
            if (ws.innerText > 0) {
                ws.innerText--;
            } else if (wm.innerText > 0 && ws.innerText == 0) {
                ws.innerText = 59;
                wm.innerText--;
            }
        } else {
            if (bm.innerText > 0 || bs.innerText > 0) {
                if (bs.innerText > 0) {
                    bs.innerText--;
                } else if (bm.innerText > 0 && bs.innerText == 0) {
                    bs.innerText = 59;
                    bm.innerText--;
                }
            } else {
                // End of Break, Reset Timer
                playNotificationSound();
                const { workDuration, breakDuration } = getUserSettings();
                updateTimerDisplay(workDuration, 0, breakDuration, 0);
            }
        }


}
