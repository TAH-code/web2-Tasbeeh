export function playNotificationSound() {
    const audio = new Audio("sound1.mp3");
    audio.play();
}