export const startBtn = document.getElementById("start");
export const stopBtn = document.getElementById("stop");
export const resetBtn = document.getElementById("reset");

export const wm = document.getElementById("w_minutes");
export const ws = document.getElementById("w_seconds");

export const bm = document.getElementById("b_minutes");
export const bs = document.getElementById("b_seconds");

export const counter = document.getElementById("counter");

export function updateTimerDisplay(workMinutes, workSeconds, breakMinutes, breakSeconds) {
    wm.innerText = workMinutes;
    ws.innerText = workSeconds < 10 ? "0" + workSeconds : workSeconds;

    bm.innerText = breakMinutes;
    bs.innerText = breakSeconds < 10 ? "0" + breakSeconds : breakSeconds;
}
