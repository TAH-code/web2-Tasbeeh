export function getUserSettings() {
    return {
        workDuration: 25, 
        breakDuration: 5, 
    };
}
